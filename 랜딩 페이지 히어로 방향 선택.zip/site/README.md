# Hani, Speaking — 랜딩 페이지

GitHub Pages에 바로 올릴 수 있는 단일 파일 사이트입니다.

## 파일 구조

```
site/
├── index.html      ← 모든 HTML/CSS가 이 안에 들어 있습니다 (JS 없음)
├── images/         ← 사진을 넣을 폴더 (선택)
│   ├── immerse.jpg
│   ├── practice.jpg
│   ├── make-it-yours.jpg
│   ├── challenge.jpg
│   ├── book.jpg
│   └── hani.jpg
└── README.md
```

`index.html` 하나만 올려도 사이트는 정상 작동합니다. 사진은 넣기 전까지 회색 자리표시 박스로 보입니다.

## 올리는 방법 (GitHub Pages)

1. GitHub에서 새 저장소(repository)를 만듭니다. 예: `korean-hani`
2. `index.html`을 저장소 **루트**에 업로드합니다. (Add file → Upload files)
3. 저장소 **Settings → Pages**로 이동
4. Source를 **Deploy from a branch**, Branch를 **main / (root)** 으로 선택 후 Save
5. 1~2분 후 `https<!---->://{아이디}.github.io/{저장소이름}/` 에서 열립니다.

도메인을 연결하려면 Settings → Pages → Custom domain에 입력하세요.

## 사진 넣기

1. `images/` 폴더를 만들고 사진을 업로드합니다.
2. `index.html`에서 자리표시 박스를 찾아 교체합니다.

바꾸기 전:
```html
<div class="thumb"><div class="ph">images/immerse.jpg</div></div>
```

바꾼 후:
```html
<div class="thumb"><img src="images/immerse.jpg" alt="" style="height:100%;object-fit:cover"></div>
```

하니쌤 프로필 사진도 같은 방식입니다:
```html
<div class="avatar"><img src="images/hani.jpg" alt="Hani ssaem" style="height:100%;object-fit:cover"></div>
```

권장 사이즈: How it works 사진 800×540, 상품 사진 900×600, 프로필 400×400. 톤이 서로 비슷한 사진을 쓰세요.

## 문의 폼 연결

GitHub Pages는 서버가 없어서 폼을 직접 처리하지 못합니다. 무료 서비스를 연결하세요.

1. [Formspree](https://formspree.io) 가입 → 새 form 생성 → 주소 복사
2. `index.html`에서 아래 부분의 `YOUR_FORM_ID`를 교체합니다.

```html
<form action="https://formspree.io/f/YOUR_FORM_ID" method="POST">
```

제출된 질문은 등록한 이메일로 전달됩니다.

## 결제 링크

상품 버튼 2개와 푸터 링크가 `https://payhip.com/KoreanHani`로 연결돼 있습니다. 개별 상품 결제 페이지 주소로 바꾸면 전환에 더 좋습니다.

## 디자인 규칙 (수정 시 참고)

`index.html` 상단 `:root`에 색과 여백이 정리돼 있습니다. 여기만 고치면 전체에 반영됩니다.

- 배경: 크림 `#FAF4E7` ↔ 흰색 `#FFFFFF` 교대, 원칙 섹션만 연회색 `#F6F4F0`, 마지막 문의 섹션만 브라운 `#4A3520`
- 강조: 앰버 `#EBAE4A`, "No" 강조는 테라코타 `#C0512F`
- 타입: Pretendard / H1 60 → H2 44 → 본문 20
- 섹션 상하 여백 104px, 콘텐츠 최대폭 1120px
- 모바일(900px 이하)에서 3단·2단이 1단으로 바뀌고 글자 크기가 줄어듭니다.
